#!/bin/bash
#
#********************************************************************
#Author:            wangxiaochun
#QQ:                29308620
#Date:              2023-06-12
#FileName:          test.sh
#URL:               http://www.wangxiaochun.com
#Description:       The test script
#Copyright (C):     2023 All rights reserved
#********************************************************************

cat > /test.log  <<EOF
name:${name:-wang}
EOF
